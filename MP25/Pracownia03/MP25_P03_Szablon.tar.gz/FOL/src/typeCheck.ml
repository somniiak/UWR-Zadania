let check_defs _ =
  failwith "not implemented"
